<?php

declare(strict_types=1);

namespace Lenremont\PageImporter;

final class Plugin {
	private const VERSION = '0.4.0';

	private static ?self $instance = null;

	public static function instance(): self {
		if (null === self::$instance) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	public function register_hooks(): void {
		add_action('init', array($this, 'register_blocks'));
		add_action('enqueue_block_editor_assets', array($this, 'enqueue_editor_assets'));
		add_action('enqueue_block_assets', array($this, 'enqueue_canvas_assets'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
		add_filter('get_block_templates', array($this, 'normalize_registered_template_keys'));
	}

	public function normalize_registered_template_keys(array $templates): array {
		// Core's editor reads index 0, but plugin-registered templates retain a
		// string key in get_block_templates() on the tested WordPress version.
		return isset($templates['lenremont-page-importer//lenremont-landing']) ? array_values($templates) : $templates;
	}

	public function enqueue_canvas_assets(): void {
		if (is_admin()) {
			wp_enqueue_style('lenremont-page-importer');
			wp_enqueue_style('lenremont-page-importer-canvas', LENREMONT_PAGE_IMPORTER_URL . 'assets/canvas.css', array('lenremont-page-importer'), self::VERSION);
			wp_enqueue_style('lenremont-reference-original');
		}
	}

	public function register_blocks(): void {
		wp_register_style('lenremont-reference-adapter', LENREMONT_PAGE_IMPORTER_URL . 'assets/reference-adapter.css', array(), self::VERSION);
		wp_register_style('lenremont-reference-original', LENREMONT_PAGE_IMPORTER_URL . 'assets/reference/original.css', array('lenremont-reference-adapter'), self::VERSION);
		wp_register_script('lenremont-reference-blocks', LENREMONT_PAGE_IMPORTER_URL . 'assets/reference-blocks.js', array('wp-blocks', 'wp-block-editor', 'wp-element', 'wp-components'), self::VERSION, true);
		$object = array('type' => 'object', 'default' => array());
		$string = array('type' => 'string', 'default' => '');
		foreach (array(
			'element' => array('tag' => array('type' => 'string', 'default' => 'div'), 'attributes' => $object),
			'text' => array('tag' => array('type' => 'string', 'default' => 'span'), 'raw' => array('type' => 'boolean', 'default' => false), 'text' => $string, 'attributes' => $object),
			'picture' => array('attributes' => $object),
			'reference-quiz' => array('attributes' => $object),
			'art' => array('asset' => $string),
			'reference-widget' => array('widget' => $string),
		) as $name => $attributes) {
			$args = array('api_version' => 3, 'attributes' => $attributes, 'editor_script' => 'lenremont-reference-blocks');
			if (in_array($name, array('art', 'reference-widget'), true)) {
				$args['render_callback'] = static function ($attributes) use ($name): string {
					ob_start();
					include LENREMONT_PAGE_IMPORTER_DIR . 'blocks/' . $name . '/render.php';
					return (string) ob_get_clean();
				};
			}
			register_block_type('lenremont/' . $name, $args);
		}
		wp_register_style(
			'lenremont-page-importer',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/frontend.css',
			array(),
			self::VERSION
		);

		wp_register_script(
			'lenremont-page-importer-blocks',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/blocks.js',
			array('wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n'),
			self::VERSION,
			true
		);

		wp_register_script(
			'lenremont-page-importer-interactions',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/interactions.js',
			array(),
			self::VERSION,
			true
		);

		foreach (array('quiz', 'before-after', 'lead-form') as $block) {
			register_block_type(LENREMONT_PAGE_IMPORTER_DIR . 'blocks/' . $block);
		}

		if (function_exists('register_block_template')) {
			register_block_template('lenremont-page-importer//lenremont-landing', array(
				'title' => 'Ленремонт — полный лендинг',
				'description' => 'Содержимое страницы на всю ширину, без дополнительной шапки, заголовка и подвала темы.',
				'post_types' => array('page'),
				'content' => '<!-- wp:group {"tagName":"main","align":"full","className":"lr-page-canvas","layout":{"type":"default"}} --><main class="wp-block-group alignfull lr-page-canvas"><!-- wp:post-content {"align":"full","layout":{"type":"default"}} /--></main><!-- /wp:group -->',
			));
		}
	}

	public function enqueue_editor_assets(): void {
		if (! current_user_can('edit_pages')) {
			return;
		}
		wp_enqueue_script('lenremont-reference-blocks');
		$art_path = LENREMONT_PAGE_IMPORTER_DIR . 'assets/reference/art.json';
		$art = is_readable($art_path) ? json_decode((string) file_get_contents($art_path), true) : array();
		wp_add_inline_script('lenremont-reference-blocks', 'window.LenremontReferenceAssets = ' . wp_json_encode(array(
			'art' => $art,
			'choices' => array(
				array('label' => 'Восстановить обивку', 'description' => 'Трещины, разрывы, потёртости', 'icon' => 'needle'),
				array('label' => 'Изменить дизайн', 'description' => 'Новый цвет, фактура или строчка', 'icon' => 'spark'),
				array('label' => 'Разобраться с посадкой', 'description' => 'Скользко, жёстко или неудобно', 'icon' => 'seat'),
			),
		)) . ';', 'before');

		wp_enqueue_script(
			'lenremont-page-converter',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/converter.js',
			array('wp-blocks', 'lenremont-reference-blocks'),
			self::VERSION,
			true
		);

		wp_enqueue_script(
			'lenremont-page-importer-editor',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/editor.js',
			array(
				'lenremont-page-converter',
				'wp-blocks',
				'wp-components',
				'wp-data',
				'wp-edit-post',
				'wp-editor',
				'wp-element',
				'wp-i18n',
				'wp-notices',
				'wp-plugins',
			),
			self::VERSION,
			true
		);

		wp_add_inline_script(
			'lenremont-page-importer-editor',
			'window.LenremontPageImporterConfig = ' . wp_json_encode(
				array(
					'exampleUrl' => LENREMONT_PAGE_IMPORTER_URL . 'examples/main-motorcycle-seats.json',
					'pluginUrl'  => untrailingslashit(LENREMONT_PAGE_IMPORTER_URL),
				)
			) . ';',
			'before'
		);

		wp_enqueue_style(
			'lenremont-page-importer-editor',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/editor.css',
			array('wp-edit-blocks', 'lenremont-page-importer'),
			self::VERSION
		);
	}

	public function enqueue_frontend_assets(): void {
		if (! is_singular()) {
			return;
		}

		$post = get_queried_object();
		if (! $post instanceof \WP_Post) {
			return;
		}

		$content = (string) $post->post_content;
		if (false !== strpos($content, 'lr-reference')) {
			wp_enqueue_style('lenremont-reference-original');
			for ($i = 0; $i < 3; $i++) {
				wp_enqueue_script_module('lenremont-reference-' . $i, LENREMONT_PAGE_IMPORTER_URL . 'assets/reference/interaction-' . $i . '.js', array(), self::VERSION);
			}
			return;
		}
		$uses_imported_page = false !== strpos($content, 'lr-imported-page');
		$uses_plugin_block  = has_block('lenremont/quiz', $post)
			|| has_block('lenremont/before-after', $post)
			|| has_block('lenremont/lead-form', $post);

		if ($uses_imported_page || $uses_plugin_block) {
			wp_enqueue_style('lenremont-page-importer');
		}
	}
}
