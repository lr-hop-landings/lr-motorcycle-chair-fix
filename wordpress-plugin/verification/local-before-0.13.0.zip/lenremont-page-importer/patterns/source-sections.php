<?php
/** Ready section blocks seed their editable InnerBlocks from the shipped manifests. */
return array(
    'hero-main' => 'Первый экран + квиз / главная',
    'hero-motocikly' => 'Первый экран + квиз / мотоциклы',
    'hero-skutery' => 'Первый экран + квиз / скутеры',
    'hero-kvadrocikly' => 'Первый экран + квиз / квадроциклы',
    'hero-baggi' => 'Первый экран + квиз / багги',
    'messengers' => 'Мессенджеры',
    'benefits' => 'Преимущества / короткая полоса',
    'vehicles' => 'Виды техники',
    'portfolio' => 'Портфолио / до и после',
    'solutions' => 'Варианты работ',
    'materials' => 'Материалы и посадка',
    'prices' => 'Цены',
    'process' => 'Этапы работы',
    'logistics' => 'Передача сиденья',
    'quality' => 'Контроль качества',
    'faq' => 'Вопросы и ответы',
    'contact' => 'Контакты / финальный блок',
);
