import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const pluginDir = dirname(dirname(fileURLToPath(import.meta.url)));
const manifestPath = join(pluginDir, 'examples', 'main-motorcycle-seats.json');
const converterPath = join(pluginDir, 'assets', 'converter.js');
const manifestSource = readFileSync(manifestPath, 'utf8');
const manifest = JSON.parse(manifestSource.replaceAll('{{pluginUrl}}', 'http://example.test/plugin'));

const context = {
	module: { exports: {} },
	exports: {},
	globalThis: {},
};
vm.runInNewContext(readFileSync(converterPath, 'utf8'), context, { filename: converterPath });

const createBlock = (name, attributes = {}, innerBlocks = []) => ({ name, attributes, innerBlocks });
const referenceContext = { module: { exports: {} } };
vm.runInNewContext(readFileSync(join(pluginDir, 'assets/reference-blocks.js'), 'utf8'), referenceContext);
const reference = referenceContext.module.exports;
const converter = context.module.exports({ createBlock }, { LenremontReferenceBlocks: reference });
const result = converter.convertManifest(manifest);

assert.equal(manifest.version, 2);
assert.equal(manifest.sections.length, 13);
assert.equal(result.summary.sections, 13);
assert.equal(result.summary.warnings.length, 0);
assert.ok(result.summary.blocks > 100, 'Expected the full landing to produce more than 100 blocks.');
assert.equal(result.blocks[0].name, 'core/group');
assert.match(result.blocks[0].attributes.className, /lr-reference/);
const flatten = blocks => blocks.flatMap(b => [b, ...flatten(b.innerBlocks || [])]);
const all = flatten(result.blocks);
assert.equal(all.filter(b => b.name === 'lenremont/reference-quiz').length, 1);
assert.equal(all.filter(b => b.name === 'lenremont/reference-widget').length, 3);
assert.equal(all.filter(b => b.name === 'lenremont/element' && b.attributes.attributes['data-case-card'] !== undefined).length, 8);
assert.equal(all.filter(b => b.name === 'lenremont/element' && b.attributes.tag === 'details').length, 8);
assert.equal(all.filter(b => b.name === 'core/html').length, 0);
assert.ok(all.filter(b => ['core/heading','core/paragraph'].includes(b.name)).length > 70);
assert.deepEqual(JSON.parse(JSON.stringify(reference.cleanAttributes({ href: 'javascript:alert(1)', onclick: 'bad()', style: 'background:url(https://bad.test/);--vehicle-color:#244f9d', 'data-contact': '' }))), { href: '', style: '--vehicle-color:#244f9d', 'data-contact': '' });
assert.equal(reference.cleanAttributes({src:'https://example.test/a.webp'}).src, 'https://example.test/a.webp');
assert.ok(all.some(b => b.name === 'lenremont/text' && b.attributes.raw && b.attributes.text === 'Подобрать похожее решение '));
const css = readFileSync(join(pluginDir, 'assets/reference/original.css'), 'utf8');
assert.ok(css.startsWith('@charset "UTF-8";'), 'CSS must decode non-ASCII content correctly.');
assert.match(css, /font-family:"LR Reference Manrope"/);
assert.match(css, /:not\(\[data-lr-never\]\)/, 'Astro selector specificity must survive scoping.');
assert.doesNotMatch(css, /data-astro-cid-/);

console.log(JSON.stringify(result.summary));
