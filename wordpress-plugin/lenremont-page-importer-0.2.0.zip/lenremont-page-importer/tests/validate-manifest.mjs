import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';

const pluginDir = dirname(dirname(fileURLToPath(import.meta.url)));
const manifestPath = join(pluginDir, 'examples', 'main-motorcycle-seats.json');
const converterPath = join(pluginDir, 'assets', 'converter.js');
const manifestSource = readFileSync(manifestPath, 'utf8');
const manifest = JSON.parse(manifestSource.replaceAll('{{pluginUrl}}', 'http://example.test/plugin'));

const context = {
	module: { exports: {} },
	exports: {},
	globalThis: {},
};
vm.runInNewContext(readFileSync(converterPath, 'utf8'), context, { filename: converterPath });

const createBlock = (name, attributes = {}, innerBlocks = []) => ({ name, attributes, innerBlocks });
const converter = context.module.exports({ createBlock }, {});
const result = converter.convertManifest(manifest);

assert.equal(manifest.version, 1);
assert.equal(manifest.sections.length, 13);
assert.equal(result.summary.sections, 13);
assert.equal(result.summary.warnings.length, 0);
assert.ok(result.summary.blocks > 100, 'Expected the full landing to produce more than 100 blocks.');
assert.equal(result.blocks[0].name, 'core/group');
assert.match(result.blocks[0].attributes.className, /lr-theme-motorcycle/);

console.log(JSON.stringify(result.summary));
