(function () {
	'use strict';

	function initBeforeAfter(root) {
		root.querySelectorAll('[data-lr-before-after]').forEach(function (compare) {
			var range = compare.querySelector('.lr-before-after__range');
			if (!range || range.dataset.ready) return;
			range.dataset.ready = '1';
			range.addEventListener('input', function () {
				compare.style.setProperty('--lr-compare', range.value + '%');
			});
		});
	}

	function initQuiz(root) {
		root.querySelectorAll('[data-lr-quiz]').forEach(function (quiz) {
			if (quiz.dataset.ready) return;
			quiz.dataset.ready = '1';
			var question = quiz.querySelector('[data-lr-quiz-question]');
			var result = quiz.querySelector('[data-lr-quiz-result]');
			var answer = quiz.querySelector('[data-lr-quiz-answer]');
			var answerInput = quiz.querySelector('[data-lr-quiz-answer-input]');

			quiz.querySelectorAll('[data-lr-quiz-choice]').forEach(function (button) {
				button.addEventListener('click', function () {
					var choice = button.dataset.choice || button.textContent.trim();
					answer.textContent = choice;
					if (answerInput) answerInput.value = choice;
					question.hidden = true;
					result.hidden = false;
				});
			});

			var back = quiz.querySelector('[data-lr-quiz-back]');
			if (back) back.addEventListener('click', function () {
				result.hidden = true;
				question.hidden = false;
			});
		});
	}

	function initForms(root) {
		root.querySelectorAll('[data-lr-lead-form]').forEach(function (form) {
			if (form.dataset.ready) return;
			form.dataset.ready = '1';
			form.addEventListener('submit', function (event) {
				event.preventDefault();
				if (!form.reportValidity()) return;
				var status = form.querySelector('[data-lr-form-status]');
				if (status) {
					status.hidden = false;
					status.textContent = 'Тестовый режим: форма заполнена корректно. Подключение к обработчику заявок выполняется отдельно.';
				}
			});
		});
	}

	function init(root) {
		initBeforeAfter(root);
		initQuiz(root);
		initForms(root);
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', function () { init(document); });
	} else {
		init(document);
	}
})();
