# Lenremont Page Importer

Плагин добавляет в редактор Gutenberg боковую панель «Импорт страницы». Она принимает:

- структурированный Lenremont JSON;
- семантический HTML;
- готовую разметку Gutenberg.

Преобразование выполняется в браузере редактора. Результат становится обычным деревом блоков и записывается WordPress только после нажатия «Сохранить».

## Формат манифеста

```json
{
  "version": 1,
  "title": "Название страницы",
  "theme": "motorcycle",
  "sections": [
    {
      "type": "hero",
      "title": "Заголовок",
      "text": "Вводный текст",
      "image": { "src": "https://example.test/image.webp", "alt": "Описание" }
    }
  ]
}
```

Поддерживаемые типы секций: `hero`, `proof`, `links`, `cards`, `services`, `materials`, `pricing`, `process`, `portfolio`, `faq`, `contact`, `content`.

Поддерживаемые вложенные блоки: `heading`, `paragraph`, `image`, `buttons`, `list`, `separator`, `spacer`, `quote`, `details`, `cards`, `columns`, `quiz`, `beforeAfter`, `leadForm`.

## Ограничения версии 0.1.0

- HTML-режим переносит семантическую структуру и контент, но не произвольные CSS и JavaScript.
- Внешние изображения остаются внешними URL; перенос в медиатеку будет отдельным этапом.
- Формы работают в демонстрационном режиме и пока не отправляют данные в обработчик Ленремонта.
- ZIP-пакеты пока не поддерживаются.
