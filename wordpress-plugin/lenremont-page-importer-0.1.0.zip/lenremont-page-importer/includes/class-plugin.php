<?php

declare(strict_types=1);

namespace Lenremont\PageImporter;

final class Plugin {
	private const VERSION = '0.1.0';

	private static ?self $instance = null;

	public static function instance(): self {
		if (null === self::$instance) {
			self::$instance = new self();
		}

		return self::$instance;
	}

	private function __construct() {}

	public function register_hooks(): void {
		add_action('init', array($this, 'register_blocks'));
		add_action('enqueue_block_editor_assets', array($this, 'enqueue_editor_assets'));
		add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_assets'));
	}

	public function register_blocks(): void {
		wp_register_style(
			'lenremont-page-importer',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/frontend.css',
			array(),
			self::VERSION
		);

		wp_register_script(
			'lenremont-page-importer-blocks',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/blocks.js',
			array('wp-blocks', 'wp-block-editor', 'wp-components', 'wp-element', 'wp-i18n'),
			self::VERSION,
			true
		);

		wp_register_script(
			'lenremont-page-importer-interactions',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/interactions.js',
			array(),
			self::VERSION,
			true
		);

		foreach (array('quiz', 'before-after', 'lead-form') as $block) {
			register_block_type(LENREMONT_PAGE_IMPORTER_DIR . 'blocks/' . $block);
		}
	}

	public function enqueue_editor_assets(): void {
		if (! current_user_can('edit_pages')) {
			return;
		}

		wp_enqueue_script(
			'lenremont-page-converter',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/converter.js',
			array('wp-blocks'),
			self::VERSION,
			true
		);

		wp_enqueue_script(
			'lenremont-page-importer-editor',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/editor.js',
			array(
				'lenremont-page-converter',
				'wp-blocks',
				'wp-components',
				'wp-data',
				'wp-edit-post',
				'wp-editor',
				'wp-element',
				'wp-i18n',
				'wp-notices',
				'wp-plugins',
			),
			self::VERSION,
			true
		);

		wp_add_inline_script(
			'lenremont-page-importer-editor',
			'window.LenremontPageImporterConfig = ' . wp_json_encode(
				array(
					'exampleUrl' => LENREMONT_PAGE_IMPORTER_URL . 'examples/motorcycle-seats.json',
					'pluginUrl'  => untrailingslashit(LENREMONT_PAGE_IMPORTER_URL),
				)
			) . ';',
			'before'
		);

		wp_enqueue_style(
			'lenremont-page-importer-editor',
			LENREMONT_PAGE_IMPORTER_URL . 'assets/editor.css',
			array('wp-edit-blocks', 'lenremont-page-importer'),
			self::VERSION
		);
	}

	public function enqueue_frontend_assets(): void {
		if (! is_singular()) {
			return;
		}

		$post = get_queried_object();
		if (! $post instanceof \WP_Post) {
			return;
		}

		$content = (string) $post->post_content;
		$uses_imported_page = false !== strpos($content, 'lr-imported-page');
		$uses_plugin_block  = has_block('lenremont/quiz', $post)
			|| has_block('lenremont/before-after', $post)
			|| has_block('lenremont/lead-form', $post);

		if ($uses_imported_page || $uses_plugin_block) {
			wp_enqueue_style('lenremont-page-importer');
		}
	}
}
